function submitContactForm() {
    alert('Your message has been successfully submitted. We will get back to you soon.');
}